A = {i for i in input("Введите числа: ")}
B = {i for i in input("Введите числа: ")}
print(A.issubset(B))
