import json
import csv
import os
import sys



def json_to_csv(json_file):
    with open(json_file, 'r') as f:
        data = json.load(f)
    csv_file_name = os.path.splitext(json_file)[0] + '.csv'

    fields = list(data.keys())

    with open(csv_file_name, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerow(data)

    print('success')

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('usage started')
        sys.exit(1)

    json_file = sys.argv[1]

    if not os.path.exists(json_file):
        print("such file doesn`t exist")
        sys.exit(1)

    json_to_csv(json_file)