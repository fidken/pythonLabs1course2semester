str=input()
str = str.split(' ')
for i in range(len(str)):
    print(str[i][0].upper(), end='')