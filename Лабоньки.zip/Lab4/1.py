numbers = list("".join(i for i in input("Введите числа: ")).split(", "))
print(len(set(numbers))) # Множество неповторяющихся элементов